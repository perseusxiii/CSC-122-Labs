package Candle;

public class ScentedCandle extends Candle {
    private String scent;

    public String getScent() {
        return scent;
    }

    public void setScent(String scent) {
        this.scent = scent;
    }

    @Override
    public void setHeight(int height) {
        super.setHeight(height); // Set height in the parent class
        // Override price calculation to $3 per inch for ScentedCandle
        super.price = height * 3.0;
    }
}
