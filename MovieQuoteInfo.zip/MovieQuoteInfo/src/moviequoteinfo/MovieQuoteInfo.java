/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package moviequoteinfo;

/**
 *
 * @author brianmcgrail
 */
public class MovieQuoteInfo {

    
    public static void main(String[] args) {
        // Prints the favorite quote
        System.out.println("Yeah, well, you know, that's just, like, your opinion, man.");
        // Prints the movie name
        System.out.println("Movie: The Big Lebowski");
        // Prints the character who said it
        System.out.println("Character: The Dude");
        // Prints the year of the movie
        System.out.println("Year: 1998"); 
    }
    
}
