/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package songlyrics;

/**
 *
 * @author brianmcgrail
 */
public class SongLyrics {

    public static void main(String[] args) {
        // Prints 4 lines of lyrics to the song "Gooey" by Glass Animals
        System.out.println("Right, my little pooh bear, wanna take a chance?");
        System.out.println("Wanna sip the smooth air, kick it in the sand");
        System.out.println("I'd say I told you so but you just gonna cry");
        System.out.println("You just wanna know those peanut butter vibes");
    }
    
}
