
package Horse;

// RaceHorse subclass
public class RaceHorse extends Horse {
    private int races;

    // Getter and setter methods for races
    public int getRaces() {
        return races;
    }
    public void setRaces(int races) {
        this.races = races;
    }
}
