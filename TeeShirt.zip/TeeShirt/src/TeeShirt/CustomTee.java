
package TeeShirt;

public class CustomTee extends TeeShirt {
    private String slogan;

    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }

    public String getSlogan() {
        return slogan;
    }
}

