public class Circle {
    public static void main(String[] args) {
        final double PI = 3.14159;
        int radius = 10;
        
        // Calculate area and circumference for radius 10
        double area1 = PI * radius * radius;
        double circumference1 = 2 * PI * radius;
        System.out.println("The area of a circle with radius " + radius + " is " + area1);
        System.out.println("The circumference of a circle with radius " + radius + " is " + circumference1);
    }
}
